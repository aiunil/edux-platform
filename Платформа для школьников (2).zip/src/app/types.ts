export type EventType = 'olympiad' | 'competition' | 'startup' | 'program';

export interface Resource {
  name: string;
  url: string;
}

export interface Event {
  id: string;
  title: string;
  type: EventType;
  description: string;
  organizer: string;
  deadline: string;
  startDate: string;
  endDate?: string;
  location: string;
  ageGroup: string;
  tags: string[];
  prize?: string;
  website: string;
  imageUrl: string;
  registrationOpen: boolean;
  forWhom: string;
  whatToDo: string;
  whatYouGet: string;
  isFree: boolean;
  category: string;
  level: 'national' | 'international';
  subject: string;
  classes: string;
  resources: Resource[];
}