import { Heart, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import type { Event } from '../types';

interface EventCardProps {
  event: Event;
  isFavorite: boolean;
  onToggleFavorite: (eventId: string) => void;
  onClick: () => void;
}

const typeLabels: Record<Event['type'], string> = {
  olympiad: 'Олимпиада',
  competition: 'Конкурс',
  startup: 'Стартап',
  program: 'Программа'
};

const typeColors: Record<Event['type'], string> = {
  olympiad: 'bg-purple-100 text-purple-800',
  competition: 'bg-blue-100 text-blue-800',
  startup: 'bg-green-100 text-green-800',
  program: 'bg-orange-100 text-orange-800'
};

export function EventCard({ event, isFavorite, onToggleFavorite, onClick }: EventCardProps) {
  const deadlineDate = new Date(event.deadline);
  const isDeadlineSoon = (deadlineDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24) <= 7;

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow group flex flex-col h-full">
      <div className="relative h-48 overflow-hidden">
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 right-3">
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full bg-white/90 hover:bg-white"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(event.id);
            }}
          >
            <Heart
              className={`w-4 h-4 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
            />
          </Button>
        </div>
        {!event.registrationOpen && (
          <div className="absolute top-3 left-3">
            <Badge variant="secondary" className="bg-gray-800/80 text-white">
              Регистрация закрыта
            </Badge>
          </div>
        )}
      </div>

      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <Badge className={typeColors[event.type]}>
            {typeLabels[event.type]}
          </Badge>
          {isDeadlineSoon && event.registrationOpen && (
            <Badge variant="destructive" className="text-xs">
              Скоро дедлайн
            </Badge>
          )}
        </div>
        <h3 className="text-lg mt-2 text-gray-900 line-clamp-2">
          {event.title}
        </h3>
      </CardHeader>

      <CardContent className="flex-1 space-y-3">
        <div>
          <p className="text-xs text-gray-500 mb-1">Для кого</p>
          <p className="text-sm text-gray-900">{event.forWhom}</p>
        </div>
        
        <div>
          <p className="text-xs text-gray-500 mb-1">Что нужно сделать</p>
          <p className="text-sm text-gray-900 line-clamp-2">{event.whatToDo}</p>
        </div>
        
        <div>
          <p className="text-xs text-gray-500 mb-1">Что получишь</p>
          <p className="text-sm text-gray-900 line-clamp-2">{event.whatYouGet}</p>
        </div>

        <div className="pt-2">
          <Badge variant={event.isFree ? "default" : "secondary"} className="text-xs">
            {event.isFree ? '🆓 Бесплатно' : '💳 Платно'}
          </Badge>
        </div>

        {/* Ресурсы для подготовки */}
        {event.resources && event.resources.length > 0 && (
          <div className="pt-3 border-t">
            <p className="text-xs text-gray-500 mb-2">Ресурсы для подготовки</p>
            <div className="space-y-1">
              {event.resources.slice(0, 2).map((resource, index) => (
                <a
                  key={index}
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 hover:underline"
                  onClick={(e) => e.stopPropagation()}
                >
                  <ExternalLink className="w-3 h-3" />
                  {resource.name}
                </a>
              ))}
              {event.resources.length > 2 && (
                <p className="text-xs text-gray-500">+{event.resources.length - 2} больше</p>
              )}
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter>
        <Button 
          className="w-full" 
          onClick={onClick}
          disabled={!event.registrationOpen}
        >
          {event.registrationOpen ? 'Подать заявку' : 'Регистрация закрыта'}
        </Button>
      </CardFooter>
    </Card>
  );
}