import { Sparkles } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl text-gray-900">EDUX</h1>
            <p className="text-sm text-gray-600">Образовательная платформа для школьников 5–11 классов</p>
          </div>
        </div>
      </div>
    </header>
  );
}