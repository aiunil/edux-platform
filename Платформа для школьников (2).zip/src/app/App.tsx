import { useState } from 'react';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { CategoryGrid } from './components/CategoryGrid';
import { EventCard } from './components/EventCard';
import { EventModal } from './components/EventModal';
import { mockEvents } from './data/mockEvents';
import type { Event, EventType } from './types';

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<EventType | 'all'>('all');
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categoryTags, setCategoryTags] = useState<string[]>([]);

  const filteredEvents = mockEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.organizer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.subject.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || event.type === selectedType;
    const matchesCategory = categoryTags.length === 0 || 
                           categoryTags.some(tag => 
                             event.tags.some(eventTag => 
                               eventTag.toLowerCase().includes(tag.toLowerCase())
                             ) ||
                             event.category.toLowerCase().includes(tag.toLowerCase()) ||
                             event.subject.toLowerCase().includes(tag.toLowerCase())
                           );
    return matchesSearch && matchesType && matchesCategory;
  });

  const handleCategoryClick = (tags: string[]) => {
    if (categoryTags.length > 0 && categoryTags.every(tag => tags.includes(tag))) {
      // Deselect if clicking the same category
      setCategoryTags([]);
      setSelectedCategory(null);
    } else {
      // Select new category
      setCategoryTags(tags);
      // Find which category was clicked based on tags
      const categoryId = tags.includes('ИВТ') || tags.includes('Информатика') ? 'informatics' :
                        tags.includes('Математика') ? 'math' :
                        tags.includes('Физика') ? 'physics' :
                        tags.includes('География') ? 'geography' :
                        tags.includes('Экономика') ? 'economics' :
                        tags.includes('Право') || tags.includes('МО') ? 'law' :
                        tags.includes('Космос') || tags.includes('Астрономия') ? 'space' :
                        tags.includes('Английский') ? 'english' : null;
      setSelectedCategory(categoryId);
    }
  };

  const toggleFavorite = (eventId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(eventId)) {
        newFavorites.delete(eventId);
      } else {
        newFavorites.add(eventId);
      }
      return newFavorites;
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <FilterBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedType={selectedType}
          onTypeChange={setSelectedType}
        />

        <div className="mt-6">
          <CategoryGrid
            selectedCategory={selectedCategory}
            onCategoryClick={handleCategoryClick}
          />
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map(event => (
            <EventCard
              key={event.id}
              event={event}
              isFavorite={favorites.has(event.id)}
              onToggleFavorite={toggleFavorite}
              onClick={() => setSelectedEvent(event)}
            />
          ))}
        </div>

        {filteredEvents.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">
              Мероприятия не найдены. Попробуйте изменить критерии поиска.
            </p>
          </div>
        )}
      </main>

      {selectedEvent && (
        <EventModal
          event={selectedEvent}
          isFavorite={favorites.has(selectedEvent.id)}
          onToggleFavorite={toggleFavorite}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  );
}